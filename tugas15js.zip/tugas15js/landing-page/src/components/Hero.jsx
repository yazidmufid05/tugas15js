import React from 'react';
import './Hero.css'; 

function Hero(){

    const title = [
        'Nama Lengkap:',
        'Asal:',
        'Umur:',
        'Status:',
        'Cita-Cita:',
        'Instagram:',
        'WhatsApp:',
        'Quotes;',
        
    ]

    const user = [
        'Panggil Aja Yazid',
        'Surabaya',
        '18 Tahun',
        'Cuma Bisa Vale',
        'Programmer',
        'yyxxzz.d',
        '085806882458',
        'Allah Itu Benci Dosa, Bukan Seorang Pendosa.',
    ]
    
    return (
        <div className="hero-container">
            {title.map((item, index) => (
                <div key={index} className="info-item">
                    <h5 className="title">{item}</h5>
                    <h3 className="user">{user[index]}</h3>
                </div>
            ))}
        </div>
    )
}

export default Hero;
