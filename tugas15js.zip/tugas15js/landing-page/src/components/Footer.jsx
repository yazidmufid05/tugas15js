
import styled from 'styled-components';

const Tagline = styled.div`
  background-image: url('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRdsnMwZQAPwMlq7MscyYEMeZMxcepqWqDuMw&usqp=CAU');
  padding: 30px;
  text-align: center;
  margin-top: 20px;
`;

const TextTagline = styled.p`
  color: white;
  font-size: 1.2rem;
`;

function Footer() {
  return (
    <Tagline>
      <TextTagline>© 2023 By S I M P L E ポ</TextTagline>
    </Tagline>
    
  );
}



export default Footer;
 